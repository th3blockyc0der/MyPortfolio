﻿using System;

namespace MathApp
{
    public class MathProgram
    {
        static void Main(string[] args)
        {
            Console.WriteLine("5 different math methods");
            Console.ReadLine();
            Console.WriteLine("first is the area of a circle");
            Console.Write("enter the radius: ");
            double radius= Convert.ToDouble(Console.ReadLine());
            double area= Math.PI * Math.Pow(radius, 2);
            Console.WriteLine($"formula: 3.14 * {radius}^2");
            Console.WriteLine($"answer: {Math.Round(area, 2)}");
            Console.WriteLine("next is rounding off");
            Console.Write("think of a number with 2 decimals: ");
            double dec= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"you think of {Math.Round(dec, 1)}");
            Console.WriteLine("next we have rasing the power");
            Console.Write("enter a number and we will divide it by 2: ");
            double raise= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"so {raise} will have raised the power of 2");
            Console.WriteLine($"the result would be {Math.Pow(raise, 2) / 2}");
            Console.WriteLine("this time we make a square root");
            Console.Write("think of a small number, one that won't exceed 20: ");
            double root= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"{root} 's square root is {Math.Sqrt(root)}");
            Console.WriteLine("lastly is logarithmic expression");
            Console.Write("enter the number: ");
            double log= Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"{log} 's log is {Math.Log(log)}");
        }
    }
}