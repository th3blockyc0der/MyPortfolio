let inventory = [
    { id: 1, name: "Cake", price: 120 },
    { id: 2, name: "Ensaymada", price: 10 },
    { id: 3, name: "Cupcake", price: 20 },
    { id: 4, name: "Panlegaspi", price: 5}
];
let cart = [];
let salesHistory = []; // MIS data
let salesChart = null;

// login
function handleLogin() {
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    if(user === "admin" && pass === "1234") {
        document.getElementById('login-overlay').style.display = 'none';
    } else {
        document.getElementById('login-error').innerText = "Wrong credentials!";
    }
}

// for the navigation buttons
function showSection(id) {
    document.querySelectorAll('main section').forEach(s => s.classList.add('hidden'));
    document.getElementById(id).classList.remove('hidden');
    if(id === 'transaction') renderProducts();
    if(id === 'inventory') renderInventory();
    if(id === 'analytics') updateAnalytics();
}

// RENDER PRODUCTS WITH FILTERING (Search)
function renderProducts() {
    const searchTerm = document.getElementById('pos-search').value.toLowerCase();
    const grid = document.getElementById('product-grid');
    const filtered = inventory.filter(item => item.name.toLowerCase().includes(searchTerm));
    
    grid.innerHTML = filtered.map(item => `
        <div class="product-card" onclick="addToCart(${item.id})">
            <strong>${item.name}</strong><br>
            ₱${item.price}
        </div>
    `).join('');
}

//add or remove an item from the inventory
function renderInventory() {
    const tbody = document.getElementById('inventory-body');
    tbody.innerHTML = inventory.map(item => `
        <tr>
            <td>${item.name}</td>
            <td>₱${item.price}</td>
            <td>
                <button onclick="editItem(${item.id})" style="background:#ffc0cb; border:none; padding:5px; cursor:pointer">Edit</button>
                <button onclick="removeItem(${item.id})" style="background:#ff4d6d; color:white; border:none; padding:5px; cursor:pointer">Delete</button>
            </td>
        </tr>
    `).join('');
}

function addItem() {
    const id = document.getElementById('edit-id').value;
    const name = document.getElementById('item-name').value;
    const price = document.getElementById('item-price').value;

    if(name && price) {
        if(id) {
            const index = inventory.findIndex(i => i.id == id);
            inventory[index] = { id: parseInt(id), name, price: parseFloat(price) };
            document.getElementById('edit-id').value = '';
            document.getElementById('add-btn').innerText = 'Add Item';
        } else {
            inventory.push({ id: Date.now(), name, price: parseFloat(price) });
        }
        document.getElementById('item-name').value = '';
        document.getElementById('item-price').value = '';
        renderInventory();
    }
}
// used ti add items from the inventory
function editItem(id) {
    const item = inventory.find(i => i.id === id);
    document.getElementById('edit-id').value = item.id;
    document.getElementById('item-name').value = item.name;
    document.getElementById('item-price').value = item.price;
    document.getElementById('add-btn').innerText = 'Update Item';
}

function removeItem(id) {
    inventory = inventory.filter(item => item.id !== id);
    renderInventory();
}

// cart
function addToCart(id) {
    const item = inventory.find(i => i.id === id);
    cart.push(item);
    updateCartDisplay();
}

function updateCartDisplay() {
    const list = document.getElementById('cart-list');
    const totalDisp = document.getElementById('cart-total');
    list.innerHTML = cart.map(i => `<li>${i.name} - ₱${i.price}</li>`).join('');
    totalDisp.innerText = cart.reduce((sum, item) => sum + item.price, 0).toFixed(2);
}

function clearCart() {
    if(cart.length === 0) return;
    const total = cart.reduce((sum, item) => sum + item.price, 0);
    
    // data recorded here
    salesHistory.push({ time: new Date().toLocaleTimeString(), amount: total });
    
    alert("Transaction Complete!");
    cart = [];
    updateCartDisplay();
}

// charts are used here
function updateAnalytics() {
    const totalRev = salesHistory.reduce((s, a) => s + a.amount, 0);
    document.getElementById('total-revenue').innerText = `₱${totalRev.toFixed(2)}`;
    document.getElementById('total-orders').innerText = salesHistory.length;

    const ctx = document.getElementById('salesChart').getContext('2d');
    if (salesChart) {
        salesChart.destroy();
    }
    // displays the chart
    salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: salesHistory.map(s => s.time),
            datasets: [{
                label: 'Revenue Growth',
                data: salesHistory.map(s => s.amount),
                borderColor: '#f8f40a',
                backgroundColor: 'rgb(249, 241, 242)',
                fill: true
            }]
        }
    });
}
//for settings
function applySettings() {
    const newName = document.getElementById('set-name').value;
    const newColor = document.getElementById('set-color').value;
    document.getElementById('display-name').innerText = newName;
    document.getElementById('page-title').innerText = newName + " POS";
    document.documentElement.style.setProperty('--primary-color', newColor);
}

// Initialize
renderProducts();